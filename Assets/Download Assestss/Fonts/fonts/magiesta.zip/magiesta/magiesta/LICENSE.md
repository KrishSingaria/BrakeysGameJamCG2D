***Note of the author***

This font is for personal projects only if you want to use this font for your commercial project please buy this font here,   
 <https://mokatype.com/magiesta-elegant-sans-serif/>